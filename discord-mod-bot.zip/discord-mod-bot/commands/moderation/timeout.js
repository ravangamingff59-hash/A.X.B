const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { sendModLog } = require('../../utils/modLog');

const UNIT_MS = {
  m: 60_000,
  h: 3_600_000,
  d: 86_400_000,
};

function parseDuration(input) {
  const match = /^(\d+)([mhd])$/.exec(input.trim());
  if (!match) return null;
  const [, amount, unit] = match;
  return Number(amount) * UNIT_MS[unit];
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Timeout (mute) a member for a set duration')
    .addUserOption((opt) => opt.setName('target').setDescription('Member to timeout').setRequired(true))
    .addStringOption((opt) =>
      opt.setName('duration').setDescription('Duration, e.g. 10m, 2h, 1d (max 28d)').setRequired(true)
    )
    .addStringOption((opt) => opt.setName('reason').setDescription('Reason for the timeout').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('target');
    const durationStr = interaction.options.getString('duration');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    const ms = parseDuration(durationStr);
    if (!ms || ms > 28 * 86_400_000) {
      return interaction.reply({
        content: 'Invalid duration. Use a format like `10m`, `2h`, or `1d` (max 28 days).',
        ephemeral: true,
      });
    }

    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    if (!member) {
      return interaction.reply({ content: 'That user is not in this server.', ephemeral: true });
    }
    if (!member.moderatable) {
      return interaction.reply({ content: 'I cannot timeout this member (role hierarchy or missing permissions).', ephemeral: true });
    }

    await member.timeout(ms, reason);

    await sendModLog(interaction.client, {
      action: 'timeout',
      target,
      moderator: interaction.user,
      reason,
      extra: `Duration: ${durationStr}`,
    });

    return interaction.reply({ content: `**${target.tag}** was timed out for ${durationStr}. Reason: ${reason}` });
  },
};
