const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { sendModLog } = require('../../utils/modLog');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('untimeout')
    .setDescription('Remove an active timeout from a member')
    .addUserOption((opt) => opt.setName('target').setDescription('Member to un-timeout').setRequired(true))
    .addStringOption((opt) => opt.setName('reason').setDescription('Reason').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('target');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    if (!member) {
      return interaction.reply({ content: 'That user is not in this server.', ephemeral: true });
    }
    if (!member.isCommunicationDisabled()) {
      return interaction.reply({ content: 'That member is not currently timed out.', ephemeral: true });
    }

    await member.timeout(null, reason);

    await sendModLog(interaction.client, {
      action: 'timeout',
      target,
      moderator: interaction.user,
      reason,
      extra: 'Timeout removed',
    });

    return interaction.reply({ content: `Timeout removed for **${target.tag}**.` });
  },
};
