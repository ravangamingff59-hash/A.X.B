const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { sendModLog } = require('../../utils/modLog');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unban')
    .setDescription('Unban a user by their ID')
    .addStringOption((opt) => opt.setName('user_id').setDescription('The user ID to unban').setRequired(true))
    .addStringOption((opt) => opt.setName('reason').setDescription('Reason for the unban').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(interaction) {
    const userId = interaction.options.getString('user_id');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    const bans = await interaction.guild.bans.fetch();
    if (!bans.has(userId)) {
      return interaction.reply({ content: 'That user is not banned.', ephemeral: true });
    }

    await interaction.guild.bans.remove(userId, reason);

    await sendModLog(interaction.client, {
      action: 'unban',
      target: { id: userId, tag: userId },
      moderator: interaction.user,
      reason,
    });

    return interaction.reply({ content: `User \`${userId}\` was unbanned. Reason: ${reason}` });
  },
};
