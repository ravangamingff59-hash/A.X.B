const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { sendModLog } = require('../../utils/modLog');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('clear')
    .setDescription('Bulk delete messages in this channel')
    .addIntegerOption((opt) =>
      opt.setName('amount').setDescription('Number of messages (1-100)').setRequired(true).setMinValue(1).setMaxValue(100)
    )
    .addUserOption((opt) => opt.setName('target').setDescription('Only delete messages from this user').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  async execute(interaction) {
    const amount = interaction.options.getInteger('amount');
    const target = interaction.options.getUser('target');

    await interaction.deferReply({ ephemeral: true });

    const messages = await interaction.channel.messages.fetch({ limit: 100 });
    let toDelete = messages;
    if (target) {
      toDelete = messages.filter((m) => m.author.id === target.id).first(amount);
    } else {
      toDelete = messages.first(amount);
    }

    const deleted = await interaction.channel.bulkDelete(toDelete, true).catch(() => null);
    const count = deleted ? deleted.size : 0;

    await sendModLog(interaction.client, {
      action: 'clear',
      target: target || `#${interaction.channel.name}`,
      moderator: interaction.user,
      reason: `Bulk delete in #${interaction.channel.name}`,
      extra: `${count} message(s) deleted`,
    });

    return interaction.editReply({ content: `Deleted ${count} message(s).` });
  },
};
