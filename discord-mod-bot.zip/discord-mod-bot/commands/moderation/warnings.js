const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { getWarnings, clearWarnings, removeWarning } = require('../../utils/warningStore');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warnings')
    .setDescription('View or manage a member\'s warnings')
    .addSubcommand((sub) =>
      sub
        .setName('list')
        .setDescription('List warnings for a member')
        .addUserOption((opt) => opt.setName('target').setDescription('Member').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName('clear')
        .setDescription('Clear all warnings for a member')
        .addUserOption((opt) => opt.setName('target').setDescription('Member').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName('remove')
        .setDescription('Remove a single warning by ID')
        .addUserOption((opt) => opt.setName('target').setDescription('Member').setRequired(true))
        .addStringOption((opt) => opt.setName('warning_id').setDescription('Warning ID').setRequired(true))
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const target = interaction.options.getUser('target');

    if (sub === 'list') {
      const warnings = getWarnings(interaction.guild.id, target.id);
      if (warnings.length === 0) {
        return interaction.reply({ content: `${target.tag} has no warnings.`, ephemeral: true });
      }
      const embed = new EmbedBuilder()
        .setTitle(`Warnings for ${target.tag}`)
        .setColor(0xf39c12)
        .setDescription(
          warnings
            .map((w, i) => `**${i + 1}.** \`${w.id}\` — ${w.reason}\n<t:${Math.floor(new Date(w.timestamp).getTime() / 1000)}:R> by <@${w.moderatorId}>`)
            .join('\n\n')
        );
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (sub === 'clear') {
      const count = clearWarnings(interaction.guild.id, target.id);
      return interaction.reply({ content: `Cleared ${count} warning(s) for **${target.tag}**.` });
    }

    if (sub === 'remove') {
      const warningId = interaction.options.getString('warning_id');
      const removed = removeWarning(interaction.guild.id, target.id, warningId);
      return interaction.reply({
        content: removed ? `Removed warning \`${warningId}\`.` : `No warning found with ID \`${warningId}\`.`,
        ephemeral: !removed,
      });
    }
  },
};
