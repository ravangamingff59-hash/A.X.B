const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { addWarning, getWarnings } = require('../../utils/warningStore');
const { sendModLog } = require('../../utils/modLog');

const AUTO_TIMEOUT_AT = 3; // auto-timeout after this many warnings
const AUTO_TIMEOUT_MS = 60 * 60 * 1000; // 1 hour

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Issue a warning to a member')
    .addUserOption((opt) => opt.setName('target').setDescription('Member to warn').setRequired(true))
    .addStringOption((opt) => opt.setName('reason').setDescription('Reason for the warning').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('target');
    const reason = interaction.options.getString('reason');

    addWarning(interaction.guild.id, target.id, interaction.user.id, reason);
    const warnings = getWarnings(interaction.guild.id, target.id);

    await sendModLog(interaction.client, {
      action: 'warn',
      target,
      moderator: interaction.user,
      reason,
      extra: `Total warnings: ${warnings.length}`,
    });

    let followUp = '';
    if (warnings.length >= AUTO_TIMEOUT_AT) {
      const member = await interaction.guild.members.fetch(target.id).catch(() => null);
      if (member && member.moderatable) {
        await member.timeout(AUTO_TIMEOUT_MS, `Automatic timeout: reached ${warnings.length} warnings`);
        followUp = ` They have reached ${warnings.length} warnings and were automatically timed out for 1 hour.`;
      }
    }

    target.send(`You were warned in **${interaction.guild.name}**. Reason: ${reason}`).catch(() => null);

    return interaction.reply({
      content: `**${target.tag}** has been warned (${warnings.length} total). Reason: ${reason}.${followUp}`,
    });
  },
};
