# Advanced Moderation Discord Bot

A slash-command Discord moderation bot built with discord.js v14: kick, ban, unban, timeout,
warnings (with auto-timeout escalation), bulk message deletion, mod-action logging, and an
automod layer (spam, invite links, mass mentions, banned words).

## Features

- `/kick`, `/ban`, `/unban`
- `/timeout` (e.g. `10m`, `2h`, `1d`) and `/untimeout`
- `/warn`, `/warnings list|clear|remove` — warnings persist in `data/warnings.json`;
  reaching 3 warnings auto-times-out the member for 1 hour (configurable)
- `/clear` — bulk delete messages, optionally filtered by user
- `/ping`
- Automod (`events/messageCreate.js`): rate-based spam detection, Discord invite blocking,
  mass-mention blocking, and a banned-word filter — all configurable in
  `utils/automodConfig.js`
- All actions post an embed to a configured mod-log channel

## Setup

1. **Create the bot application** at https://discord.com/developers/applications, add a Bot user,
   and enable the **Server Members** and **Message Content** privileged intents.
2. **Install dependencies**
   ```bash
   npm install
   ```
3. **Configure environment** — copy `.env.example` to `.env` and fill in:
   ```
   DISCORD_TOKEN=   # Bot token
   CLIENT_ID=       # Application ID
   GUILD_ID=        # Your test server ID (omit for global deploy)
   LOG_CHANNEL_ID=  # Channel ID for mod-action logs
   ```
4. **Register slash commands**
   ```bash
   npm run deploy
   ```
5. **Invite the bot** with the `bot` and `applications.commands` scopes and at minimum these
   permissions: Kick Members, Ban Members, Moderate Members, Manage Messages, Send Messages,
   Read Message History.
6. **Run it**
   ```bash
   npm start
   ```

## Project structure

```
commands/
  moderation/   kick, ban, unban, timeout, untimeout, warn, warnings, clear
  utility/      ping
events/         ready, interactionCreate, messageCreate (automod)
utils/          warningStore.js, modLog.js, automodConfig.js
data/           warnings.json (created/persisted at runtime)
index.js        bot entry point
deploy-commands.js  registers slash commands
```

## Customizing automod

Edit `utils/automodConfig.js`:
- `BANNED_WORDS` — words/phrases to auto-delete
- `SPAM_WINDOW_MS` / `SPAM_MESSAGE_LIMIT` — spam rate threshold
- `MASS_MENTION_THRESHOLD` — mentions-per-message limit
- `BLOCK_DISCORD_INVITES` — toggle invite-link blocking
- `EXEMPT_ROLE_IDS` / `EXEMPT_USER_IDS` — staff/roles skipped by automod

## Notes

- Warnings are stored in a plain JSON file for simplicity. For production/multi-shard use,
  swap `utils/warningStore.js` for a real database (SQLite, PostgreSQL, MongoDB, etc.).
- The bot requires its own role to sit **above** any role it needs to moderate.
