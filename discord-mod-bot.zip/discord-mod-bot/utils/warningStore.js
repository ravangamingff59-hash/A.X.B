const fs = require('fs');
const path = require('path');

const DATA_FILE = path.join(__dirname, '..', 'data', 'warnings.json');

function ensureFile() {
  if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(DATA_FILE, JSON.stringify({}, null, 2));
  }
}

function readAll() {
  ensureFile();
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch {
    return {};
  }
}

function writeAll(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

function addWarning(guildId, userId, moderatorId, reason) {
  const data = readAll();
  data[guildId] = data[guildId] || {};
  data[guildId][userId] = data[guildId][userId] || [];
  const entry = {
    id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
    moderatorId,
    reason,
    timestamp: new Date().toISOString(),
  };
  data[guildId][userId].push(entry);
  writeAll(data);
  return entry;
}

function getWarnings(guildId, userId) {
  const data = readAll();
  return (data[guildId] && data[guildId][userId]) || [];
}

function clearWarnings(guildId, userId) {
  const data = readAll();
  if (data[guildId]) {
    const count = (data[guildId][userId] || []).length;
    delete data[guildId][userId];
    writeAll(data);
    return count;
  }
  return 0;
}

function removeWarning(guildId, userId, warningId) {
  const data = readAll();
  if (!data[guildId] || !data[guildId][userId]) return false;
  const before = data[guildId][userId].length;
  data[guildId][userId] = data[guildId][userId].filter((w) => w.id !== warningId);
  writeAll(data);
  return data[guildId][userId].length < before;
}

module.exports = {
  addWarning,
  getWarnings,
  clearWarnings,
  removeWarning,
};
