const { EmbedBuilder } = require('discord.js');

const COLORS = {
  ban: 0xe74c3c,
  kick: 0xe67e22,
  timeout: 0xf1c40f,
  warn: 0xf39c12,
  unban: 0x2ecc71,
  clear: 0x3498db,
  automod: 0x9b59b6,
};

async function sendModLog(client, { action, target, moderator, reason, extra }) {
  const channelId = process.env.LOG_CHANNEL_ID;
  if (!channelId) return;

  const channel = await client.channels.fetch(channelId).catch(() => null);
  if (!channel) return;

  const embed = new EmbedBuilder()
    .setColor(COLORS[action] || 0x95a5a6)
    .setTitle(`Moderation Action: ${action.toUpperCase()}`)
    .addFields(
      { name: 'Target', value: target ? `${target.tag ?? target} (${target.id ?? 'n/a'})` : 'N/A', inline: true },
      { name: 'Moderator', value: moderator ? `${moderator.tag} (${moderator.id})` : 'System', inline: true },
      { name: 'Reason', value: reason || 'No reason provided' }
    )
    .setTimestamp();

  if (extra) embed.addFields({ name: 'Details', value: String(extra) });

  channel.send({ embeds: [embed] }).catch(() => null);
}

module.exports = { sendModLog };
