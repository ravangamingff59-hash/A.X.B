module.exports = {
  // Anti-spam: max messages per window before action
  SPAM_WINDOW_MS: 6000,
  SPAM_MESSAGE_LIMIT: 6,

  // Mute duration applied for automod violations
  AUTOMOD_TIMEOUT_MS: 5 * 60 * 1000, // 5 minutes

  // Invite links / mass mentions / banned words
  BLOCK_DISCORD_INVITES: true,
  MASS_MENTION_THRESHOLD: 6,
  BANNED_WORDS: [
    // Add lowercase words/phrases to auto-delete + warn.
    // e.g. 'badword1', 'badword2'
  ],

  // Roles/users exempt from automod (fill with role/user IDs)
  EXEMPT_ROLE_IDS: [],
  EXEMPT_USER_IDS: [],
};
