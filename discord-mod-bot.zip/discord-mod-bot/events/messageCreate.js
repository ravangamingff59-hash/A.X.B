const { sendModLog } = require('../utils/modLog');
const config = require('../utils/automodConfig');

// In-memory spam tracker: userId -> array of timestamps
const messageTimestamps = new Map();

const INVITE_REGEX = /(discord\.gg|discord(app)?\.com\/invite)\/\S+/i;

function isExempt(member) {
  if (!member) return false;
  if (config.EXEMPT_USER_IDS.includes(member.id)) return true;
  return member.roles.cache.some((r) => config.EXEMPT_ROLE_IDS.includes(r.id));
}

async function punish(message, reason) {
  await message.delete().catch(() => null);

  const member = message.member;
  if (member && member.moderatable) {
    await member.timeout(config.AUTOMOD_TIMEOUT_MS, `Automod: ${reason}`).catch(() => null);
  }

  await sendModLog(message.client, {
    action: 'automod',
    target: message.author,
    moderator: message.client.user,
    reason,
    extra: `Channel: #${message.channel.name}`,
  });

  message.channel
    .send(`${message.author}, your message was removed by automod (${reason}).`)
    .then((m) => setTimeout(() => m.delete().catch(() => null), 5000))
    .catch(() => null);
}

module.exports = {
  name: 'messageCreate',
  async execute(message) {
    if (message.author.bot || !message.guild) return;
    if (isExempt(message.member)) return;

    const content = message.content.toLowerCase();

    // 1. Banned words
    if (config.BANNED_WORDS.some((w) => content.includes(w))) {
      return punish(message, 'prohibited language');
    }

    // 2. Discord invite links
    if (config.BLOCK_DISCORD_INVITES && INVITE_REGEX.test(message.content)) {
      return punish(message, 'posting an invite link');
    }

    // 3. Mass mentions
    const mentionCount = message.mentions.users.size + message.mentions.roles.size;
    if (mentionCount >= config.MASS_MENTION_THRESHOLD) {
      return punish(message, 'mass mentions');
    }

    // 4. Spam (rate-based)
    const now = Date.now();
    const timestamps = (messageTimestamps.get(message.author.id) || []).filter(
      (t) => now - t < config.SPAM_WINDOW_MS
    );
    timestamps.push(now);
    messageTimestamps.set(message.author.id, timestamps);

    if (timestamps.length > config.SPAM_MESSAGE_LIMIT) {
      messageTimestamps.set(message.author.id, []);
      return punish(message, 'spamming messages');
    }
  },
};
